if (localStorage.getItem("customerid")) {
  localStorage.removeItem("customerid");
  window.location.href = "index.html";
}
