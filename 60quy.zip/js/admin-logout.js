if (localStorage.getItem("adminid")) {
  localStorage.removeItem("adminid");
  window.location.href = "index.html";
}
